from datetime import datetime
from functools import reduce

# ==========================================================
# HOTEL RESERVATION SYSTEM
# ==========================================================

# -------------------- DECORATOR ----------------------------

def log_action(func):
    def wrapper(*args, **kwargs):
        print("\n" + "=" * 50)
        print(f"Action: {func.__name__}")
        print("=" * 50)
        return func(*args, **kwargs)
    return wrapper


# -------------------- GENERATOR ----------------------------

def generate_booking_id():
    number = 1001
    while True:
        yield f"B{number}"
        number += 1


booking_generator = generate_booking_id()


# -------------------- ROOM CLASS ---------------------------

class Room:
    def __init__(self, room_no, room_type, price):
        self.room_no = room_no
        self.room_type = room_type
        self.price = price
        self.is_available = True

    def display(self):
        status = "Available" if self.is_available else "Booked"

        print(
            f"Room: {self.room_no} | "
            f"Type: {self.room_type} | "
            f"Price: ₹{self.price} | "
            f"Status: {status}"
        )


# -------------------- CUSTOMER CLASS -----------------------

class Customer:
    def __init__(self, name, phone, email):
        self.name = name
        self.phone = phone
        self.email = email

    def display(self):
        print(f"Name  : {self.name}")
        print(f"Phone : {self.phone}")
        print(f"Email : {self.email}")


# -------------------- RESERVATION CLASS --------------------

class Reservation:
    def __init__(self, booking_id, customer, room, nights):
        self.booking_id = booking_id
        self.customer = customer
        self.room = room
        self.nights = nights
        self.date = datetime.now()

    def calculate_bill(self):
        return self.room.price * self.nights

    def display(self):
        print("\nBooking ID :", self.booking_id)
        print("Date       :", self.date.strftime("%d-%m-%Y %H:%M"))
        print("Customer   :", self.customer.name)
        print("Room No    :", self.room.room_no)
        print("Room Type  :", self.room.room_type)
        print("Nights     :", self.nights)
        print("Total Bill : ₹", self.calculate_bill())


# -------------------- HOTEL CLASS ---------------------------

class Hotel:

    def __init__(self, name):
        self.name = name

        # Dictionary
        self.rooms = {
            101: Room(101, "Single", 1500),
            102: Room(102, "Single", 1500),
            201: Room(201, "Double", 2500),
            202: Room(202, "Double", 2500),
            301: Room(301, "Deluxe", 4000),
            302: Room(302, "Deluxe", 4000)
        }

        # List
        self.reservations = []

    # ---------------- DISPLAY ROOMS ----------------

    @log_action
    def display_rooms(self):

        print("ROOM DETAILS")

        for room in self.rooms.values():
            room.display()

    # ---------------- SEARCH ROOM ------------------

    def search_rooms(self, room_type):

        # List comprehension
        available_rooms = [
            room for room in self.rooms.values()
            if room.room_type.lower() == room_type.lower()
            and room.is_available
        ]

        if available_rooms:
            print("\nAvailable Rooms:")
            for room in available_rooms:
                room.display()
        else:
            print("No rooms available.")

    # ---------------- BOOK ROOM ---------------------

    @log_action
    def book_room(self):

        try:

            name = input("Enter customer name: ")
            phone = input("Enter phone number: ")
            email = input("Enter email: ")

            room_no = int(input("Enter room number: "))
            nights = int(input("Enter number of nights: "))

            if room_no not in self.rooms:
                print("Invalid room number.")
                return

            room = self.rooms[room_no]

            if not room.is_available:
                print("Room is already booked.")
                return

            if nights <= 0:
                print("Number of nights must be greater than 0.")
                return

            customer = Customer(name, phone, email)

            booking_id = next(booking_generator)

            reservation = Reservation(
                booking_id,
                customer,
                room,
                nights
            )

            room.is_available = False

            self.reservations.append(reservation)

            print("\nRoom booked successfully!")
            reservation.display()

            self.save_to_file(reservation)

        except ValueError:
            print("Please enter valid numeric values.")

    # ---------------- CANCEL BOOKING ----------------

    @log_action
    def cancel_booking(self):

        booking_id = input("Enter booking ID: ").upper()

        for reservation in self.reservations:

            if reservation.booking_id == booking_id:

                reservation.room.is_available = True

                self.reservations.remove(reservation)

                print("Booking cancelled successfully.")
                return

        print("Booking ID not found.")

    # ---------------- VIEW BOOKINGS -----------------

    @log_action
    def view_bookings(self):

        if not self.reservations:
            print("No bookings found.")
            return

        for reservation in self.reservations:
            reservation.display()

    # ---------------- SEARCH BOOKING ----------------

    def search_booking(self):

        booking_id = input("Enter booking ID: ").upper()

        for reservation in self.reservations:

            if reservation.booking_id == booking_id:
                reservation.display()
                return

        print("Booking not found.")

    # ---------------- SAVE FILE ---------------------

    def save_to_file(self, reservation):

        with open("hotel_bookings.txt", "a") as file:

            file.write(
                f"{reservation.booking_id},"
                f"{reservation.customer.name},"
                f"{reservation.room.room_no},"
                f"{reservation.nights},"
                f"{reservation.calculate_bill()}\n"
            )

    # ---------------- STATISTICS --------------------

    def statistics(self):

        if not self.reservations:
            print("No booking data available.")
            return

        bills = [
            reservation.calculate_bill()
            for reservation in self.reservations
        ]

        # Lambda
        highest_bill = max(bills, key=lambda x: x)

        # Reduce
        total_revenue = reduce(lambda x, y: x + y, bills)

        print("\nSTATISTICS")
        print("Total bookings :", len(self.reservations))
        print("Total revenue  : ₹", total_revenue)
        print("Highest bill   : ₹", highest_bill)


# ==========================================================
# POLYMORPHISM EXAMPLE
# ==========================================================

class Payment:

    def pay(self, amount):
        print(f"Payment of ₹{amount} completed.")


class UPI(Payment):

    def pay(self, amount):
        print(f"₹{amount} paid using UPI.")


class Card(Payment):

    def pay(self, amount):
        print(f"₹{amount} paid using Card.")


# ==========================================================
# MAIN PROGRAM
# ==========================================================

hotel = Hotel("Royal Palace Hotel")


while True:

    print("\n")
    print("=" * 50)
    print("       ROYAL PALACE HOTEL")
    print("=" * 50)

    print("1. Display Rooms")
    print("2. Search Room")
    print("3. Book Room")
    print("4. Cancel Booking")
    print("5. View Bookings")
    print("6. Search Booking")
    print("7. Statistics")
    print("8. Exit")

    choice = input("\nEnter your choice: ")

    if choice == "1":

        hotel.display_rooms()

    elif choice == "2":

        room_type = input(
            "Enter room type (Single/Double/Deluxe): "
        )

        hotel.search_rooms(room_type)

    elif choice == "3":

        hotel.book_room()

    elif choice == "4":

        hotel.cancel_booking()

    elif choice == "5":

        hotel.view_bookings()

    elif choice == "6":

        hotel.search_booking()

    elif choice == "7":

        hotel.statistics()

    elif choice == "8":

        print("Thank you for using Royal Palace Hotel!")
        break

    else:

        print("Invalid choice. Please try again.")
